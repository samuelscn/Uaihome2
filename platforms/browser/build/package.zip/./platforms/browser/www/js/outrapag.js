 <style>
        #logotipo{
            width: 358px;
            height: 60px;
            margin: 25px;
            margin-top: -350px;
        }
        .input-boton{
            border-radius: 5px;
        }
        .input-boton input{
            width: 600px;
            height: 43px;
            border-radius: 5px;
            background-color: #0695ED;
            margin: 90px;
            font:bold 18px sans-serif;
            color: #FFFFFF;  
            margin-top: 800px; 
        }
        .input-boton01{
            border-radius: 5px;
            margin-top: -70px;
        }
        .input-boton01 input{
            width: 300px;
            height: 43px;
            border-radius: 5px;
            background-color: #FFFFFF;
            margin: 238px;
            font:bold 18px sans-serif;
            color: #0695ED;
            margin-top: -100px;
            border-bottom: 1px solid #FFFFFF;
            border-left: 1px solid #FFFFFF;
            border-right: 1px solid #FFFFFF;
            border-top: 1px solid #FFFFFF;
        }
    </style>

    <div id="logotipo">
        <img src="img/logo.png">
        
    </div>
    <div class="input-boton" id="input-cad">
        <input type="button" onClick= window.location="page2.html" value="Começar agora">
    </div>
    <div class="input-boton01" id="input-open">
        <input type="button" value="Já tenho uma conta">
    </div>